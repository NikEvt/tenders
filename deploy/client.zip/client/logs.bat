@echo off
chcp 65001 >nul
cd /d "%~dp0"

rem Журналы всех сервисов сразу. Ctrl+C — выход.
rem Один сервис: logs.bat crawler   (crawler, docs-worker, research, llm-service, api)

echo.
echo Журналы. Выход — Ctrl+C.
echo.
docker compose logs -f --tail=200 %*
