@echo off
chcp 65001 >nul
setlocal

rem Загружает образы из архива поставки в локальный Docker. Выполняется один раз
rem при установке и повторно — при получении новой версии.

cd /d "%~dp0"

echo.
echo === Установка «Закупки» ===
echo.

docker version >nul 2>&1
if errorlevel 1 (
    echo [ОШИБКА] Docker не отвечает.
    echo Запустите Docker Desktop, дождитесь зелёного значка и повторите.
    echo.
    pause
    exit /b 1
)

if not exist "images.tar.gz" (
    echo [ОШИБКА] Не найден файл images.tar.gz рядом с install.bat.
    echo Распакуйте архив поставки целиком, не по частям.
    echo.
    pause
    exit /b 1
)

echo Загрузка образов. Это занимает 5-15 минут и требует около 8 ГБ на диске.
echo.
docker load -i images.tar.gz
if errorlevel 1 (
    echo.
    echo [ОШИБКА] Загрузить образы не удалось.
    echo Чаще всего причина — нехватка места на диске C:.
    echo.
    pause
    exit /b 1
)

echo.
echo Образы загружены. Дальше запустите start.bat.
echo.
pause
