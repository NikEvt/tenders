@echo off
chcp 65001 >nul
setlocal

rem Запуск системы. При первом вызове создаёт .env и останавливается: без токена
rem ЕИС и ключа LLM запускаться незачем — краулер и отбор всё равно не поедут.

cd /d "%~dp0"

echo.
echo === Закупки: запуск ===
echo.

docker version >nul 2>&1
if errorlevel 1 (
    echo [ОШИБКА] Docker не отвечает.
    echo Запустите Docker Desktop, дождитесь зелёного значка и повторите.
    echo.
    pause
    exit /b 1
)

for /f %%i in ('docker image ls -q zakupki-api') do set HAVE_IMAGES=1
if not defined HAVE_IMAGES (
    echo [ОШИБКА] Образы не загружены. Сначала запустите install.bat.
    echo.
    pause
    exit /b 1
)

if not exist ".env" (
    powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0setup.ps1"
    if errorlevel 1 (
        pause
        exit /b 1
    )
    echo Сейчас откроется .env в Блокноте. Впишите EIS_TOKEN и LLM_API_KEY,
    echo сохраните файл, закройте Блокнот и запустите start.bat снова.
    echo.
    pause
    notepad ".env"
    exit /b 0
)

rem Точка в шаблоне требует хотя бы один символ после знака равенства.
findstr /R /C:"^EIS_TOKEN=." ".env" >nul
if errorlevel 1 (
    echo [ОШИБКА] В файле .env не заполнен EIS_TOKEN — токен личного кабинета ЕИС.
    echo Откройте .env, впишите значение и повторите запуск.
    echo.
    pause
    notepad ".env"
    exit /b 1
)

findstr /R /C:"^LLM_API_KEY=." ".env" >nul
if errorlevel 1 (
    echo [ОШИБКА] В файле .env не заполнен LLM_API_KEY — ключ доступа к модели.
    echo Откройте .env, впишите значение и повторите запуск.
    echo.
    pause
    notepad ".env"
    exit /b 1
)

rem Шаблон приезжает с заглушкой folder-id. Про неё легко забыть, а отказ
rem всплывёт далеко — в журнале llm-service на первом же обращении к модели.
findstr /C:"<folder-id>" ".env" >nul
if not errorlevel 1 (
    echo [ВНИМАНИЕ] В LLM_MODEL остался образец ^<folder-id^>.
    echo Подставьте свой идентификатор каталога Yandex Cloud, иначе фильтры,
    echo сводки и отбор работать не будут. Краулер и разбор документов поедут.
    echo.
)

echo Поднимаю сервисы. Первый запуск дольше остальных: создаётся база,
echo накатываются миграции, разворачивается брокер — до 5 минут.
echo.

docker compose up -d
if errorlevel 1 (
    echo.
    echo [ОШИБКА] Запустить стек не удалось. Что смотреть:
    echo   logs.bat            — журналы сервисов
    echo   docker compose ps   — какие контейнеры поднялись
    echo.
    pause
    exit /b 1
)

echo.
echo Жду готовности API.
set /a ATTEMPT=0
:wait
set /a ATTEMPT+=1
curl -sf -o nul http://localhost:8000/health/ready
if not errorlevel 1 goto ready
if %ATTEMPT% GEQ 60 (
    echo.
    echo [ВНИМАНИЕ] API не ответил за 5 минут. Стек продолжает подниматься.
    echo Посмотрите журналы: logs.bat
    echo.
    pause
    exit /b 1
)
timeout /t 5 /nobreak >nul
goto wait

:ready
echo.
echo Готово. Интерфейс: http://localhost:3000
echo.
start "" http://localhost:3000
